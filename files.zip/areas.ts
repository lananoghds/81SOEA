export type AreaKey = "infra" | "hashtags" | "people" | "program" | "tv";

export interface AreaItem {
  name: string;
  group: string; // categoria, formato ou grupo conforme a área
  mentions: number;
  reach: number;
  engagement: number;
  sentiment: { positivo: number; neutro: number; negativo: number };
  platforms: Record<string, number>;
  trend: number[];
  axis: string;
  space?: string | undefined;
  date?: string | undefined;
  hour?: string | undefined;
  person?: string | undefined;
}

export interface AreaPost {
  id: string;
  item: string;
  author: string;
  handle: string;
  platform: string;
  text: string;
  sentiment: "Positivo" | "Neutro" | "Negativo";
  engagement: number;
  time: string;
  url?: string | undefined;
  profile?: string | undefined;
}

export interface AreaDataset {
  key: AreaKey;
  items: AreaItem[];
  posts: AreaPost[];
  groupLabel: string;
  itemLabel: string;
}
