import { kpis, platforms, sentiment, topics, peakSummary } from "@/mocks/dashboard";
import { areaData, areaMeta } from "@/mocks/soea-areas";
import { deriveAreaAlerts } from "@/components/dashboard/area-views";
import type { AreaKey } from "@/types/areas";

const ORANGE = "F28C28";
const DARK = "1F2937";
const fmt = new Intl.NumberFormat("pt-BR");

export async function exportDashboardPpt(period: string) {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";

  const header = (slide: ReturnType<typeof pptx.addSlide>, title: string) => {
    slide.addShape("rect", { x: 0, y: 0, w: 13.33, h: 0.12, fill: { color: ORANGE } });
    slide.addText(title, { x: 0.5, y: 0.3, w: 10, h: 0.6, fontSize: 26, bold: true, color: DARK, fontFace: "Arial" });
    slide.addText(`81ª SOEA · Período: ${period} · Fonte: V-Tracker`, { x: 0.5, y: 0.85, w: 12, h: 0.35, fontSize: 11, color: "6B7280" });
  };

  // Capa
  const cover = pptx.addSlide();
  cover.background = { color: ORANGE };
  cover.addText("Monitoramento da 81ª SOEA", { x: 0.6, y: 2.6, w: 12, h: 1, fontSize: 40, bold: true, color: "FFFFFF" });
  cover.addText(`Social Listening e Performance Digital · ${period}`, { x: 0.6, y: 3.6, w: 12, h: 0.5, fontSize: 18, color: "FFFFFF" });

  // 1. Visão Geral — reproduz exatamente os dados atuais
  const ov = pptx.addSlide();
  header(ov, "1. Visão Geral");
  kpis.forEach((k, i) => {
    const x = 0.5 + (i % 3) * 4.15;
    const y = 1.4 + Math.floor(i / 3) * 1.3;
    ov.addShape("roundRect", { x, y, w: 3.95, h: 1.15, fill: { color: "F9FAFB" }, line: { color: "E5E7EB" }, rectRadius: 0.08 });
    ov.addText(k.label, { x: x + 0.15, y: y + 0.08, w: 3.6, h: 0.3, fontSize: 11, color: "6B7280" });
    ov.addText(k.value, { x: x + 0.15, y: y + 0.38, w: 3.6, h: 0.45, fontSize: 22, bold: true, color: DARK });
    ov.addText(k.change ?? k.detail, { x: x + 0.15, y: y + 0.8, w: 3.6, h: 0.28, fontSize: 9, color: ORANGE });
  });
  ov.addChart("doughnut", [{ name: "Sentimento", labels: sentiment.map((s) => s.name), values: sentiment.map((s) => s.value) }], {
    x: 0.5, y: 4.2, w: 4, h: 3, showLegend: true, legendPos: "b", chartColors: ["22C55E", "9CA3AF", "EF4444"], showTitle: true, title: "Distribuição de sentimento", titleFontSize: 12,
  });
  ov.addChart("bar", [{ name: "Plataformas", labels: platforms.map((p) => p.name), values: platforms.map((p) => p.value) }], {
    x: 4.7, y: 4.2, w: 4.2, h: 3, barDir: "bar", chartColors: [ORANGE], showTitle: true, title: "Onde estão falando (%)", titleFontSize: 12,
  });
  ov.addTable(
    [[{ text: "Assunto", options: { bold: true } }, { text: "Volume", options: { bold: true } }], ...topics.slice(0, 5).map((t) => [t.name, fmt.format(t.volume)].map((text) => ({ text })))],
    { x: 9.1, y: 4.3, w: 3.8, fontSize: 10, border: { type: "solid", color: "E5E7EB", pt: 0.5 } },
  );
  ov.addText(`Pico: ${peakSummary.time} · ${fmt.format(peakSummary.mentions)} menções · ${peakSummary.topic}`, { x: 0.5, y: 7.1, w: 12, h: 0.3, fontSize: 10, color: "6B7280" });

  // 2-6. Áreas
  const keys: AreaKey[] = ["infra", "hashtags", "people", "program", "tv"];
  keys.forEach((key, idx) => {
    const d = areaData[key];
    const s = pptx.addSlide();
    header(s, `${idx + 2}. ${areaMeta[key].title}`);
    if (!d.items.length) {
      s.addText("Não há dados suficientes para esta área.", { x: 0.5, y: 3, w: 12, h: 0.6, fontSize: 18, color: "6B7280" });
      return;
    }
    const total = d.items.reduce((a, i) => a + i.mentions, 0);
    const reach = d.items.reduce((a, i) => a + i.reach, 0);
    const eng = d.items.reduce((a, i) => a + i.engagement, 0);
    [["Ocorrências", fmt.format(total)], ["Alcance estimado", fmt.format(reach)], ["Engajamento", fmt.format(eng)]].forEach(([l, v], i) => {
      s.addText(`${l}\n${v}`, { x: 0.5 + i * 4.15, y: 1.35, w: 3.95, h: 0.9, fontSize: 16, bold: true, color: DARK, fill: { color: "F9FAFB" }, align: "center" });
    });
    const top = [...d.items].sort((a, b) => b.mentions - a.mentions).slice(0, 8);
    s.addChart("bar", [{ name: "Ocorrências", labels: top.map((i) => i.name), values: top.map((i) => i.mentions) }], {
      x: 0.5, y: 2.5, w: 6.3, h: 4.6, barDir: "bar", chartColors: [ORANGE], catAxisLabelFontSize: 9, showTitle: true, title: `${d.itemLabel}s com maior volume`, titleFontSize: 12,
    });
    const rep = [...d.items].sort((a, b) => b.engagement - a.engagement).slice(0, 6);
    s.addTable(
      [
        ["Maior repercussão", "Engaj.", "Positivo", "Negativo"].map((t) => ({ text: t, options: { bold: true, color: "FFFFFF", fill: { color: ORANGE } } })),
        ...rep.map((i) => [i.name, fmt.format(i.engagement), `${i.sentiment.positivo}%`, `${i.sentiment.negativo}%`].map((text) => ({ text }))),
      ],
      { x: 7.1, y: 2.6, w: 5.8, fontSize: 9, border: { type: "solid", color: "E5E7EB", pt: 0.5 } },
    );
    s.addText("Dados de demonstração até a integração com o V-Tracker.", { x: 0.5, y: 7.1, w: 12, h: 0.3, fontSize: 9, italic: true, color: "9CA3AF" });
  });

  // 7. Alertas
  const al = pptx.addSlide();
  header(al, "7. Alertas");
  const alerts = deriveAreaAlerts().slice(0, 9);
  if (!alerts.length) al.addText("Não há dados suficientes para gerar alertas.", { x: 0.5, y: 3, w: 12, h: 0.6, fontSize: 18 });
  else
    al.addTable(
      [
        ["Alerta", "O que aconteceu", "Quando", "Volume", "Sentimento", "Plataforma"].map((t) => ({ text: t, options: { bold: true, color: "FFFFFF", fill: { color: ORANGE } } })),
        ...alerts.map((a) => [a.type, a.what, a.when, fmt.format(a.volume), a.sentiment, a.platform].map((text) => ({ text }))),
      ],
      { x: 0.5, y: 1.4, w: 12.3, fontSize: 9, border: { type: "solid", color: "E5E7EB", pt: 0.5 } },
    );

  await pptx.writeFile({ fileName: `SOEA81-monitoramento-${period.replace(/\s/g, "")}.pptx` });
}
