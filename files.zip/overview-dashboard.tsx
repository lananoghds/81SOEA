import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  BarChart3,
  BellRing,
  ChevronRight,
  Eye,
  Flame,
  Heart,
  HelpCircle,
  MapPin,
  MessageCircle,
  Radio,
  Sparkles,
  TrendingUp,
  Users,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip as ChartTooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  cityRanking,
  conversation,
  dailyOccurrences,
  emerging,
  hashtags,
  highlights,
  kpis,
  mentions,
  monthlyOccurrences,
  monitoredTags,
  officialContents,
  peakSummary,
  platforms,
  publishers,
  sentiment,
  sentimentByPlatform,
  serviceOccurrences,
  stateRanking,
  topics,
  vTrackerIndicators,
} from "@/mocks/dashboard";
import type { Mention, Platform, Sentiment } from "@/types/dashboard";

export const panel =
  "rounded-lg border bg-card shadow-[0_1px_2px_color-mix(in_oklab,var(--foreground)_5%,transparent)]";
export const sentimentClasses: Record<Sentiment, string> = {
  Positivo: "bg-emerald-50 text-emerald-700",
  Neutro: "bg-slate-100 text-slate-600",
  Negativo: "bg-rose-50 text-rose-700",
};
export const number = new Intl.NumberFormat("pt-BR");
const platformOptions: Platform[] = [
  "Todas",
  "Instagram",
  "X",
  "Facebook",
  "YouTube",
  "LinkedIn",
  "TikTok",
  "Notícias",
];
const infoCopy: Record<string, string> = {
  "Evolução das conversas": "Evolutivo das ocorrências identificadas no período monitorado.",
  "Distribuição de sentimento":
    "Distribuição percentual das ocorrências conforme classificação recebida da fonte.",
  "Assuntos do momento": "Ranking de termos, tópicos ou assuntos com maior volume de ocorrências.",
  "Temas emergentes": "Assuntos com crescimento acelerado no recorte analisado.",
  "Onde estão falando": "Participação das plataformas nas ocorrências de social listening.",
  "Últimas menções":
    "Registros mais recentes disponíveis, preservando plataforma, autor, sentimento, engagement e URL quando houver.",
  "Picos de conversa": "Momentos em que a fonte identificou maior concentração de ocorrências.",
  "Alertas de monitoramento":
    "Alertas demonstrativos baseados em variações de volume, sentimento, assunto, plataforma ou localização.",
  "Conteúdos oficiais":
    "Publicações identificadas via social listening, sem métricas externas não disponíveis na fonte.",
  "Impacto da comunicação":
    "Leitura comparativa entre conteúdos monitorados e variação das ocorrências espontâneas.",
  "Menções em destaque":
    "Ocorrências com maior repercussão segundo engagement, comentários, RTs ou alcance estimado disponível.",
  Publicadores:
    "Análise de publicadores únicos, influentes, evangelizadores e agressores quando esses dados estiverem disponíveis.",
  "Origem das conversas":
    "Área preparada para rankings de estados, cidades e geolocalizações quando a fonte disponibilizar esses dados.",
  "Assistente BI":
    "Respostas demonstrativas e determinísticas baseadas nos dados exibidos no painel.",
};

export function InfoTip({ label, text }: { label: string; text?: string | undefined }) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 shrink-0 text-muted-foreground"
            aria-label={`Sobre ${label}`}
          >
            <HelpCircle className="h-3.5 w-3.5" />
          </Button>
        </TooltipTrigger>
        <TooltipContent
          side="top"
          className="max-w-64 bg-popover text-popover-foreground shadow-md"
        >
          <p>
            {text ?? infoCopy[label] ?? "Informação exibida conforme disponibilidade da fonte."}
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function SectionTitle({
  title,
  subtitle,
  action,
  info,
}: {
  title: string;
  subtitle?: string | undefined;
  action?: React.ReactNode;
  info?: string | undefined;
}) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 border-b px-5 py-4">
      <div className="min-w-0">
        <div className="flex items-center gap-1.5">
          <h2 className="truncate text-sm font-bold text-foreground">{title}</h2>
          <InfoTip label={title} text={info} />
        </div>
        {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

function ConversationTooltip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ payload: (typeof conversation)[number] }>;
}) {
  const item = payload?.[0]?.payload;
  if (!active || !item) return null;
  return (
    <div className="rounded-md border bg-popover p-3 text-xs shadow-lg">
      <p className="font-bold">
        {item.time} · {item.mentions} ocorrências
      </p>
      <p className={item.variation >= 0 ? "mt-1 text-emerald-600" : "mt-1 text-destructive"}>
        {item.variation > 0 ? "+" : ""}
        {item.variation}% vs. hora anterior
      </p>
      <p className="mt-2 text-muted-foreground">Assunto principal</p>
      <p className="font-medium">{item.topic}</p>
    </div>
  );
}

export function Reading({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-5 mb-5 rounded-md bg-muted p-3 text-xs text-muted-foreground">
      <strong className="text-foreground">Leitura:</strong> {children}
    </div>
  );
}

export function MiniRanking({
  items,
  suffix = "",
}: {
  items: Array<{ label: string; value: number }>;
  suffix?: string;
}) {
  if (!items.length)
    return (
      <div className="rounded-md border border-dashed bg-background p-4 text-xs text-muted-foreground">
        Dados ainda não disponíveis na fonte. Área preparada para receber os rankings reais quando a
        integração enviar essas informações.
      </div>
    );
  const max = Math.max(...items.map((item) => item.value));
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div key={item.label}>
          <div className="mb-1.5 flex justify-between text-xs">
            <span className="font-medium">{item.label}</span>
            <strong>
              {number.format(item.value)}
              {suffix}
            </strong>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary"
              style={{ width: `${(item.value / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function PublicationButton({ mention }: { mention: Pick<Mention, "url" | "author"> }) {
  if (!mention.url)
    return (
      <Button variant="ghost" size="sm" disabled className="shrink-0">
        Sem link
      </Button>
    );
  return (
    <Button variant="outline" size="sm" asChild>
      <a href={mention.url} target="_blank" rel="noopener noreferrer">
        Ver publicação <ArrowUpRight />
      </a>
    </Button>
  );
}

export function OverviewDashboard({
  platform,
  presentationMode = false,
}: {
  platform: Platform;
  presentationMode?: boolean;
}) {
  const [mentionPlatform, setMentionPlatform] = useState<Platform>("Todas");
  const [mentionSentiment, setMentionSentiment] = useState<Sentiment | "Todos">("Todos");
  const [topic, setTopic] = useState("Todos");
  const [sort, setSort] = useState("recent");
  const presentationRef = useRef<HTMLDivElement>(null);
  const effectivePlatform = platform !== "Todas" ? platform : mentionPlatform;
  const filtered = useMemo(
    () =>
      mentions
        .filter(
          (m) =>
            (effectivePlatform === "Todas" || m.platform === effectivePlatform) &&
            (mentionSentiment === "Todos" || m.sentiment === mentionSentiment) &&
            (topic === "Todos" || m.topic === topic),
        )
        .sort((a, b) => (sort === "impact" ? b.engagement - a.engagement : a.id - b.id)),
    [effectivePlatform, mentionSentiment, topic, sort],
  );
  const topPlatform = platforms[0];
  const topTopic = topics[0];
  const dominantSentiment = sentiment[0];
  const visiblePlatforms =
    platform === "Todas" ? platforms : platforms.filter((item) => item.name === platform);
  const platformReading =
    platform === "Todas" && topPlatform
      ? `${topPlatform.name} concentra a maior parte das ocorrências no período.`
      : `${platform} está selecionado no filtro global.`;

  useEffect(() => {
    const track = presentationRef.current;
    if (!presentationMode || !track) return;

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let currentSlide = 0;
    track.scrollTo({ left: 0, behavior: "auto" });

    const timer = window.setInterval(() => {
      const slides = Array.from(track.children) as HTMLElement[];
      if (!slides.length || document.hidden) return;
      currentSlide = (currentSlide + 1) % slides.length;
      const nextSlide = slides[currentSlide];
      if (!nextSlide) return;
      track.scrollTo({
        left: nextSlide.offsetLeft - track.offsetLeft,
        behavior: prefersReducedMotion ? "auto" : "smooth",
      });
    }, 11000);

    return () => window.clearInterval(timer);
  }, [presentationMode]);

  return (
    <div
      ref={presentationRef}
      className={
        presentationMode
          ? "tv-presentation-track"
          : "mx-auto max-w-[1600px] space-y-5"
      }
      aria-label={presentationMode ? "Apresentação automática dos painéis" : undefined}
    >
      <div className="space-y-5">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
        <div>
          <p className="text-xs font-semibold uppercase text-primary">Painel executivo</p>
          <h1 className="mt-1 text-2xl font-extrabold sm:text-3xl">81ª SOEA</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Visão consolidada das conversas digitais em Sergipe com V-Tracker como base de social
            listening
          </p>
        </div>
        <div className="hidden items-center gap-2 rounded-md border border-primary/25 bg-primary/5 px-3 py-2 text-xs text-muted-foreground sm:flex">
          <Radio className="h-4 w-4 text-primary" />
          Monitoramento ativo
        </div>
        </div>

        <section className="grid grid-cols-2 gap-3 xl:grid-cols-6">
        {kpis.map((kpi) => (
          <article key={kpi.label} className={`${panel} min-w-0 p-4`}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center gap-1">
                <p className="truncate text-xs font-semibold text-muted-foreground">{kpi.label}</p>
                <InfoTip label={kpi.label} text={kpi.info} />
              </div>
              <span
                className={`h-2 w-2 shrink-0 rounded-full ${kpi.tone === "green" ? "bg-emerald-500" : kpi.tone === "red" ? "bg-rose-500" : kpi.tone === "amber" ? "bg-amber-500" : "bg-sky-500"}`}
              />
            </div>
            <div className="mt-3 flex flex-wrap items-baseline gap-2">
              <strong className="text-2xl font-extrabold tabular-nums">{kpi.value}</strong>
              {kpi.change && (
                <span
                  className={`text-xs font-bold ${kpi.change.startsWith("-") && kpi.label !== "Sentimento negativo" ? "text-destructive" : "text-emerald-600"}`}
                >
                  {kpi.change}
                </span>
              )}
            </div>
            <p className="mt-1 min-h-8 text-[11px] leading-4 text-muted-foreground">{kpi.detail}</p>
          </article>
        ))}
        </section>

        <section className="grid gap-3 md:grid-cols-5">
        {vTrackerIndicators.map((item) => (
          <article key={item.label} className={`${panel} p-4`}>
            <div className="flex items-center justify-between gap-2">
              <p className="truncate text-xs font-semibold text-muted-foreground">{item.label}</p>
              <InfoTip label={item.label} text={item.info} />
            </div>
            <strong className="mt-2 block text-xl font-extrabold tabular-nums">{item.value}</strong>
          </article>
        ))}
        </section>
      </div>

      <section className="grid gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(300px,0.8fr)]">
        <article className={`${panel} min-w-0`}>
          <SectionTitle
            title="Evolução das conversas"
            subtitle="Volume de ocorrências ao longo do tempo"
            action={<span className="text-xs font-semibold text-emerald-600">+24% no período</span>}
          />
          <div className="h-80 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={conversation} margin={{ top: 12, right: 8, left: -22, bottom: 0 }}>
                <defs>
                  <linearGradient id="mentionsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.28} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="var(--border)" vertical={false} strokeDasharray="3 3" />
                <XAxis
                  dataKey="time"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "var(--muted-foreground)", fontSize: 11 }}
                />
                <ChartTooltip
                  content={<ConversationTooltip />}
                  cursor={{ stroke: "var(--primary)", strokeDasharray: "4 4" }}
                />
                <Area
                  type="monotone"
                  dataKey="mentions"
                  stroke="var(--primary)"
                  strokeWidth={2.5}
                  fill="url(#mentionsFill)"
                  activeDot={{
                    r: 5,
                    fill: "var(--primary)",
                    stroke: "var(--card)",
                    strokeWidth: 3,
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <Reading>
            O maior volume de conversas foi registrado às {peakSummary.time}, com{" "}
            {number.format(peakSummary.mentions)} ocorrências.
          </Reading>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Distribuição de sentimento"
            subtitle="Percepção das conversas analisadas"
          />
          <div className="grid grid-cols-[140px_1fr] items-center gap-2 p-5">
            <div className="relative h-36">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sentiment}
                    dataKey="value"
                    innerRadius={45}
                    outerRadius={64}
                    paddingAngle={3}
                    stroke="none"
                  >
                    {["oklch(0.66 0.15 155)", "oklch(0.72 0.03 240)", "oklch(0.63 0.22 25)"].map(
                      (color) => (
                        <Cell key={color} fill={color} />
                      ),
                    )}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <strong className="text-2xl">{dominantSentiment?.value}%</strong>
                <span className="text-[10px] text-muted-foreground">
                  {dominantSentiment?.name.toLowerCase()}
                </span>
              </div>
            </div>
            <div className="space-y-3">
              {sentiment.map((s, i) => (
                <div
                  key={s.name}
                  className="grid grid-cols-[auto_1fr_auto] items-center gap-2 text-xs"
                >
                  <span
                    className={`h-2 w-2 rounded-full ${i === 0 ? "bg-emerald-500" : i === 1 ? "bg-slate-400" : "bg-rose-500"}`}
                  />
                  <span>
                    {s.name} <strong>{s.value}%</strong>
                  </span>
                  <span className={i === 0 ? "text-emerald-600" : "text-muted-foreground"}>
                    {s.change}
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div className="mx-5 mb-4 grid gap-2">
            {sentimentByPlatform.slice(0, 3).map((row) => (
              <div
                key={row.platform}
                className="grid grid-cols-[80px_1fr] items-center gap-2 text-xs"
              >
                <span className="font-medium">{row.platform}</span>
                <div className="flex h-2 overflow-hidden rounded-full bg-muted">
                  <span className="bg-emerald-500" style={{ width: `${row.positive}%` }} />
                  <span className="bg-slate-400" style={{ width: `${row.neutral}%` }} />
                  <span className="bg-rose-500" style={{ width: `${row.negative}%` }} />
                </div>
              </div>
            ))}
          </div>
          <Reading>
            O sentimento {dominantSentiment?.name.toLowerCase()} representa a maior parcela das
            ocorrências.
          </Reading>
        </article>
      </section>

      <section className="grid gap-5 lg:grid-cols-2 xl:grid-cols-3">
        <article className={panel}>
          <SectionTitle title="Assuntos do momento" subtitle="Ranking por volume de ocorrências" />{" "}
          <div className="divide-y">
            {topics.map((t, i) => (
              <div
                key={t.name}
                className="grid grid-cols-[24px_minmax(0,1fr)_auto] items-center gap-3 px-5 py-3"
              >
                <span className="text-xs font-bold text-muted-foreground">{i + 1}</span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {number.format(t.volume)} ocorrências
                  </p>
                </div>
                <div
                  className={`flex items-center gap-1 text-xs font-semibold ${t.change > 5 ? "text-emerald-600" : t.change < 0 ? "text-destructive" : "text-muted-foreground"}`}
                >
                  {t.change > 5 ? <ArrowUp /> : t.change < 0 ? <ArrowDown /> : <span>→</span>}
                  {Math.abs(t.change)}%
                </div>
              </div>
            ))}
          </div>
          <Reading>{topTopic?.name} foi o termo mais citado no período.</Reading>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Temas emergentes"
            subtitle="Crescimento acelerado nas últimas 3 horas"
          />{" "}
          <div className="space-y-3 p-5">
            {emerging.map((item, i) => (
              <div
                key={item.name}
                className="flex items-center gap-4 rounded-md border bg-background p-4"
              >
                <div
                  className={`grid h-10 w-10 shrink-0 place-items-center rounded-md ${i === 0 ? "bg-amber-100 text-amber-700" : "bg-accent text-primary"}`}
                >
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{item.name}</p>
                  <p className="text-xs text-muted-foreground">crescimento nas conversas</p>
                </div>
                <span className="text-sm font-extrabold text-emerald-600">+{item.change}%</span>
              </div>
            ))}
          </div>
          <div className="grid gap-2 px-5 pb-5 text-xs text-muted-foreground">
            <p>
              <strong className="text-foreground">Hashtags:</strong>{" "}
              {hashtags.map((item) => item.name).join(", ")}
            </p>
            <p>
              <strong className="text-foreground">Tags por sentimento:</strong>{" "}
              {monitoredTags.map((item) => `${item.name} (${item.sentiment})`).join(", ")}
            </p>
          </div>
        </article>
        <article className={`${panel} lg:col-span-2 xl:col-span-1`}>
          <SectionTitle title="Onde estão falando" subtitle="Distribuição por plataforma" />
          <div className="space-y-3 p-5">
            {visiblePlatforms.map((p) => (
              <div key={p.name}>
                <div className="mb-1.5 flex justify-between text-xs">
                  <span className="font-medium">{p.name}</span>
                  <strong>{p.value}%</strong>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{ width: `${p.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <Reading>{platformReading}</Reading>
        </article>
      </section>

      <section className="grid gap-5 xl:grid-cols-[minmax(0,1.45fr)_minmax(320px,0.7fr)]">
        <article className={`${panel} min-w-0`}>
          <SectionTitle title="Últimas menções" subtitle="Feed consolidado de social listening" />
          <div className="flex gap-2 overflow-x-auto border-b p-3">
            <Select
              value={mentionPlatform}
              onValueChange={(v) => setMentionPlatform(v as Platform)}
              disabled={platform !== "Todas"}
            >
              <SelectTrigger className="w-32 shrink-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {platformOptions.map((p) => (
                  <SelectItem key={p} value={p}>
                    {p}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select
              value={mentionSentiment}
              onValueChange={(v) => setMentionSentiment(v as Sentiment | "Todos")}
            >
              <SelectTrigger className="w-32 shrink-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["Todos", "Positivo", "Neutro", "Negativo"].map((p) => (
                  <SelectItem key={p} value={p}>
                    {p}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={topic} onValueChange={setTopic}>
              <SelectTrigger className="w-44 shrink-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Todos">Todos os assuntos</SelectItem>
                {topics.map((t) => (
                  <SelectItem key={t.name} value={t.name}>
                    {t.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="ml-auto w-44 shrink-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Mais recentes</SelectItem>
                <SelectItem value="impact">Maior repercussão</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="divide-y">
            {filtered.length ? (
              filtered.map((m) => (
                <article key={m.id} className="p-5 transition-colors hover:bg-accent/35">
                  <div className="grid grid-cols-[auto_minmax(0,1fr)] gap-3 sm:grid-cols-[auto_minmax(0,1fr)_auto]">
                    <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-accent text-xs font-bold text-primary">
                      {m.initials}
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <a
                          href={m.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm font-bold hover:text-primary hover:underline"
                        >
                          {m.author}
                        </a>
                        <span className="text-xs text-muted-foreground">{m.handle}</span>
                        <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-semibold">
                          {m.platform}
                        </span>
                        <span className="text-[10px] text-muted-foreground">{m.publishedAt}</span>
                      </div>
                      <a
                        href={m.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-2 block text-sm leading-6 text-foreground/85 transition-colors hover:text-primary"
                      >
                        {m.text}
                      </a>
                      <div className="mt-3 flex flex-wrap items-center gap-3">
                        <span
                          className={`rounded px-2 py-1 text-[10px] font-semibold ${sentimentClasses[m.sentiment]}`}
                        >
                          {m.sentiment}
                        </span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Heart className="h-3.5 w-3.5" />
                          {m.engagement} engagement
                        </span>
                        {typeof m.comments === "number" && (
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <MessageCircle className="h-3.5 w-3.5" />
                            {m.comments} comentários
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">{m.topic}</span>
                      </div>
                    </div>
                    <div className="col-start-2 sm:col-start-3">
                      <PublicationButton mention={m} />
                    </div>
                  </div>
                </article>
              ))
            ) : (
              <p className="p-8 text-center text-sm text-muted-foreground">
                Nenhuma menção corresponde aos filtros selecionados.
              </p>
            )}
          </div>
        </article>
        <div className="min-w-0 space-y-5">
          <article className={panel}>
            <SectionTitle title="Picos de conversa" subtitle="Momentos-chave do dia" />{" "}
            <div className="space-y-5 p-5">
              {[
                {
                  time: peakSummary.time,
                  count: `${number.format(peakSummary.mentions)} ocorrências`,
                  topic: peakSummary.topic,
                  change: "+280%",
                },
                {
                  time: "11h15",
                  count: "312 ocorrências",
                  topic: "Abertura da SOEA",
                  change: "+164%",
                },
                {
                  time: "09h48",
                  count: "246 ocorrências",
                  topic: "Engenharia sustentável",
                  change: "+92%",
                },
              ].map((p, i) => (
                <div key={p.time} className="grid grid-cols-[auto_1fr_auto] gap-3">
                  <div
                    className={`grid h-9 w-9 place-items-center rounded-md ${i === 0 ? "bg-amber-100 text-amber-700" : "bg-accent text-primary"}`}
                  >
                    <Flame className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">
                      {p.time} · {p.count}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">{p.topic}</p>
                  </div>
                  <strong className="text-xs text-emerald-600">{p.change}</strong>
                </div>
              ))}
            </div>
            <div className="mx-5 mb-5 rounded-md border bg-background p-3 text-xs">
              <p>
                <strong>Dia de pico:</strong> {peakSummary.day}
              </p>
              <p className="mt-1 text-muted-foreground">
                Alcance estimado relacionado: {peakSummary.estimatedReach}
              </p>
            </div>
          </article>
          <article className={panel}>
            <SectionTitle
              title="Alertas de monitoramento"
              subtitle="Ocorrências que exigem atenção"
            />
            <div className="divide-y">
              {[
                {
                  icon: Flame,
                  title: "Pico de ocorrências",
                  text: "IA cresce 280% desde 14h32",
                  tone: "text-amber-600",
                },
                {
                  icon: BellRing,
                  title: "Mudança de sentimento",
                  text: "Alta pontual de negativo sobre acesso ao evento",
                  tone: "text-rose-600",
                },
                {
                  icon: TrendingUp,
                  title: "Novo tema em crescimento",
                  text: "Mobilidade urbana avança 184%",
                  tone: "text-primary",
                },
                {
                  icon: BarChart3,
                  title: "Concentração por plataforma",
                  text: "Instagram concentra 42% das ocorrências",
                  tone: "text-emerald-600",
                },
              ].map((a) => (
                <div key={a.title} className="flex gap-3 p-4">
                  <a.icon className={`mt-0.5 h-4 w-4 shrink-0 ${a.tone}`} />
                  <div>
                    <p className="text-xs font-bold">{a.title}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{a.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-[minmax(0,1.45fr)_minmax(320px,0.7fr)]">
        <article className={panel}>
          <SectionTitle
            title="Conteúdos oficiais"
            subtitle="Publicações identificadas no social listening"
            action={
              <Button variant="ghost" size="sm">
                Ver todos <ChevronRight />
              </Button>
            }
          />
          <div className="grid grid-cols-2 gap-px bg-border sm:grid-cols-4">
            {[
              {
                l: "Ocorrências",
                v: "2.214",
                info: "Ocorrências relacionadas a publicações monitoradas.",
              },
              {
                l: "Comentários",
                v: "2.414",
                info: "Comentários disponíveis na fonte para as publicações.",
              },
              { l: "Engagement", v: "6,8%", info: "Taxa conforme definição da fonte." },
              {
                l: "Sentimento predominante",
                v: "Positivo",
                info: "Classificação predominante nas ocorrências relacionadas.",
              },
            ].map((x) => (
              <div key={x.l} className="bg-card p-4">
                <div className="flex items-center gap-1">
                  <p className="text-[10px] uppercase text-muted-foreground">{x.l}</p>
                  <InfoTip label={x.l} text={x.info} />
                </div>
                <p className="mt-1 text-lg font-extrabold">{x.v}</p>
              </div>
            ))}
          </div>
          <div className="divide-y">
            {officialContents.map((c, i) => (
              <div
                key={c.title}
                className="grid grid-cols-[22px_minmax(0,1fr)_auto] items-center gap-3 px-5 py-3"
              >
                <span className="text-xs font-bold text-muted-foreground">{i + 1}</span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{c.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {c.type} · {number.format(c.occurrences)} ocorrências ·{" "}
                    {number.format(c.comments)} comentários
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold">{c.engagement}</p>
                  <p className="text-[10px] text-muted-foreground">engagement</p>
                </div>
              </div>
            ))}
          </div>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Impacto da comunicação"
            subtitle="Conteúdo monitorado vs. conversa espontânea"
          />
          <div className="p-5">
            <div className="rounded-md bg-primary p-5 text-primary-foreground">
              <p className="text-xs font-semibold opacity-80">PUBLICAÇÃO DE MAIOR IMPACTO</p>
              <h3 className="mt-2 text-base font-bold">Reel · IA na Engenharia</h3>
              <div className="mt-5 flex items-end justify-between">
                <div>
                  <strong className="text-3xl">+218%</strong>
                  <p className="mt-1 text-xs opacity-80">
                    ocorrências espontâneas após a publicação
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 opacity-70" />
              </div>
            </div>
            <div className="mt-5 space-y-3">
              {[
                { l: "Tempo até o pico", v: "27 min" },
                { l: "Novos publicadores", v: "1.284" },
                { l: "Sentimento positivo", v: "81%" },
              ].map((x) => (
                <div key={x.l} className="flex justify-between border-b pb-3 text-sm">
                  <span className="text-muted-foreground">{x.l}</span>
                  <strong>{x.v}</strong>
                </div>
              ))}
            </div>
          </div>
        </article>
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-start gap-1">
            <div>
              <h2 className="text-sm font-bold">Menções em destaque</h2>
              <p className="text-xs text-muted-foreground">Publicações com maior repercussão</p>
            </div>
            <InfoTip label="Menções em destaque" />
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {highlights.map((h) => (
            <article
              key={h.author}
              className={`${panel} flex flex-col p-5 transition-colors hover:border-primary/40 hover:bg-accent/25`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <a
                    href={h.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-bold hover:text-primary hover:underline"
                  >
                    {h.author}
                  </a>
                  <p className="text-xs text-muted-foreground">{h.platform}</p>
                </div>
                <span
                  className={`rounded px-2 py-1 text-[10px] font-semibold ${sentimentClasses[h.sentiment]}`}
                >
                  {h.sentiment}
                </span>
              </div>
              <a
                href={h.url}
                target="_blank"
                rel="noopener noreferrer"
                className="my-4 block flex-1 text-sm leading-6 transition-colors hover:text-primary"
              >
                “{h.excerpt}”
              </a>
              <div className="grid grid-cols-3 gap-2 border-t pt-4 text-center">
                <div>
                  <Eye className="mx-auto h-3.5 w-3.5 text-muted-foreground" />
                  <strong className="mt-1 block text-xs">{h.estimatedReach}</strong>
                  <span className="text-[9px] text-muted-foreground">alcance est.</span>
                </div>
                <div>
                  <Heart className="mx-auto h-3.5 w-3.5 text-muted-foreground" />
                  <strong className="mt-1 block text-xs">{h.engagement}</strong>
                  <span className="text-[9px] text-muted-foreground">engagement</span>
                </div>
                <div>
                  <MessageCircle className="mx-auto h-3.5 w-3.5 text-muted-foreground" />
                  <strong className="mt-1 block text-xs">{h.rts ?? h.comments}</strong>
                  <span className="text-[9px] text-muted-foreground">
                    {h.rts ? "RTs" : "coment."}
                  </span>
                </div>
              </div>
              <Button variant="ghost" size="sm" asChild className="mt-3 w-full">
                <a href={h.url} target="_blank" rel="noopener noreferrer">
                  Ver publicação <ArrowUpRight />
                </a>
              </Button>
            </article>
          ))}
        </div>
      </section>

      <section className="grid gap-5 lg:grid-cols-2">
        <article className={panel}>
          <SectionTitle title="Publicadores" subtitle="Influentes, evangelizadores e agressores" />
          <div className="divide-y">
            {publishers.map((publisher) => (
              <div key={publisher.handle} className="grid grid-cols-[auto_1fr_auto] gap-3 p-4">
                <div className="grid h-9 w-9 place-items-center rounded-md bg-accent text-primary">
                  <Users className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold">{publisher.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {publisher.handle} · {publisher.platform} · {publisher.profile}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold">{publisher.value}</p>
                  <span
                    className={`rounded px-2 py-1 text-[10px] font-semibold ${sentimentClasses[publisher.sentiment]}`}
                  >
                    {publisher.sentiment}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Origem das conversas"
            subtitle="Estados, cidades e geolocalizações"
          />
          <div className="grid gap-4 p-5">
            <div>
              <div className="mb-2 flex items-center gap-1 text-xs font-bold">
                <MapPin className="h-3.5 w-3.5 text-primary" />
                Ranking dos estados
              </div>
              <MiniRanking items={stateRanking} />
            </div>
            <div>
              <div className="mb-2 text-xs font-bold">Ranking das cidades</div>
              <MiniRanking items={cityRanking} />
            </div>
          </div>
        </article>
      </section>

      <div className="space-y-5">
        <section className="grid gap-5 md:grid-cols-3">
        <article className={panel}>
          <SectionTitle
            title="Ocorrências por dia"
            subtitle="Recorte demonstrativo"
            info="Evolução por dia quando a fonte disponibilizar esse agrupamento."
          />
          <div className="p-5">
            <MiniRanking items={dailyOccurrences} />
          </div>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Ocorrências por mês"
            subtitle="Recorte demonstrativo"
            info="Evolução por mês quando a fonte disponibilizar esse agrupamento."
          />
          <div className="p-5">
            <MiniRanking items={monthlyOccurrences} />
          </div>
        </article>
        <article className={panel}>
          <SectionTitle
            title="Ocorrências por serviço"
            subtitle="Agrupamento da fonte"
            info="Distribuição das ocorrências por serviço ou tipo de origem conforme a fonte."
          />
          <div className="p-5">
            <MiniRanking items={serviceOccurrences} suffix="%" />
          </div>
        </article>
        </section>

        <footer className="flex flex-wrap items-center justify-between gap-2 border-t px-1 py-4 text-xs text-muted-foreground">
          <span className="font-semibold text-foreground">Fonte: V-Tracker</span>
          <span>Última sincronização: 14:45</span>
        </footer>
      </div>
    </div>
  );
}
