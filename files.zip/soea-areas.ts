// Dados de DEMONSTRAÇÃO para as novas áreas. Serão substituídos pelos dados
// reais do V-Tracker (public.mentions) quando a integração estiver ativa.
import type { AreaDataset, AreaItem, AreaPost, AreaKey } from "@/types/areas";

export const thematicAxes = [
  "Energia e Conectividade",
  "Mobilidade",
  "Água",
  "Bem-Estar Social e Cidadania",
  "Meio Ambiente e Sustentabilidade",
  "Saneamento Básico",
  "Agroindústria",
] as const;

export const crossThemes = [
  "Inteligência Artificial", "Inovação", "Engenharia", "Agronomia", "Geociências",
  "Infraestrutura", "Desenvolvimento sustentável", "Mudanças climáticas", "Tecnologia",
  "Dados", "Cidades inteligentes", "Políticas públicas", "Energia", "Transição energética",
  "Saneamento", "Recursos hídricos", "Agricultura", "Agroindústria", "Mineração",
  "Petróleo e gás", "Pré-sal", "Construção civil",
];

export const periodLabels = ["Dia 1", "Dia 2", "Dia 3", "Dia 4", "Dia 5"];
const platformsList = ["Instagram", "X", "Facebook", "YouTube", "LinkedIn", "TikTok", "Notícias"] as const;

// Gerador determinístico (sem aleatoriedade real) para manter consistência.
function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

type Seed = Omit<AreaItem, "trend" | "platforms" | "sentiment" | "reach" | "engagement"> & {
  pos: number;
  neg: number;
};

function build(seeds: Seed[], salt: number): AreaItem[] {
  return seeds.map((s, i) => {
    const r = seeded(salt * 100 + i + 1);
    const weights = platformsList.map(() => r());
    const total = weights.reduce((a, b) => a + b, 0);
    const platforms = Object.fromEntries(
      platformsList.map((p, idx) => [p, Math.round((s.mentions * (weights[idx] ?? 0)) / total)]),
    );
    const base = [0.12, 0.18, 0.26, 0.24, 0.2].map((f) => f * (0.8 + r() * 0.4));
    const sum = base.reduce((a, b) => a + b, 0);
    const trend = base.map((f) => Math.round((s.mentions * f) / sum));
    return {
      ...s,
      sentiment: { positivo: s.pos, neutro: 100 - s.pos - s.neg, negativo: s.neg },
      reach: Math.round(s.mentions * (180 + r() * 220)),
      engagement: Math.round(s.mentions * (2 + r() * 4)),
      platforms,
      trend,
    };
  });
}

const authors: Array<[string, string]> = [
  ["Crea-SE", "@creasergipe"], ["Confea", "@confeaoficial"], ["Ana Beatriz Lima", "@anabeatriz.eng"],
  ["Portal Infonet", "@infonet"], ["Rafael Menezes", "@rafaelagro"], ["Juliana Prado", "@ju.civil"],
  ["G1 Sergipe", "@g1se"], ["Mútua", "@mutuaoficial"], ["Carlos Andrade", "@carlos.eletrica"],
];
const sentiments = ["Positivo", "Neutro", "Negativo"] as const;

function postsFor(items: AreaItem[], templates: string[], salt: number): AreaPost[] {
  const out: AreaPost[] = [];
  items.forEach((item, i) => {
    const r = seeded(salt * 1000 + i + 7);
    for (let k = 0; k < 3; k++) {
      const a = authors[Math.floor(r() * authors.length)] ?? authors[0]!;
      const roll = r() * 100;
      const sentiment =
        roll < item.sentiment.positivo ? sentiments[0] : roll < item.sentiment.positivo + item.sentiment.neutro ? sentiments[1] : sentiments[2];
      const tpl = templates[(i + k) % templates.length] ?? "";
      out.push({
        id: `${salt}-${i}-${k}`,
        item: item.name,
        author: a[0],
        handle: a[1],
        platform: platformsList[Math.floor(r() * 5)] ?? "Instagram",
        text: tpl.replace("{x}", item.name),
        sentiment,
        engagement: Math.round(40 + r() * 900),
        time: `${periodLabels[Math.floor(r() * 5)]} · ${String(9 + Math.floor(r() * 10)).padStart(2, "0")}h${String(Math.floor(r() * 60)).padStart(2, "0")}`,
        profile: a[1] === "@creasergipe" || a[1] === "@confeaoficial" ? "Perfil SOEA" : undefined,
      });
    }
  });
  return out;
}

const infraSeeds: Seed[] = [
  ["Credenciamento / filas", 612, 38, 34], ["Internet / Wi-Fi", 548, 30, 41], ["Estacionamento", 431, 35, 37],
  ["Climatização", 322, 52, 18], ["Praça de alimentação", 298, 61, 14], ["Auditórios", 284, 74, 6],
  ["Som e audiovisual", 236, 58, 15], ["Sinalização", 204, 46, 22], ["Transporte", 192, 44, 26],
  ["Acessibilidade", 176, 63, 12], ["Estandes", 168, 79, 4], ["Banheiros", 152, 40, 30],
  ["Alimentação", 141, 57, 16], ["Salas", 128, 66, 9], ["Arenas", 117, 81, 3], ["Palcos", 109, 83, 3],
  ["Conectividade", 98, 34, 38], ["Estrutura física", 94, 69, 8], ["Atendimento ao participante", 88, 71, 10],
].map(([name, mentions, pos, neg]) => ({
  name: name as string, group: "Infraestrutura", mentions: mentions as number, pos: pos as number, neg: neg as number,
  axis: "Bem-Estar Social e Cidadania",
}));

const hashtagSeeds: Seed[] = [
  ["#SOEA81", 1184, 76, 4, "Energia e Conectividade"], ["#Engenharia", 846, 72, 5, "Energia e Conectividade"],
  ["#Sergipe", 624, 70, 6, "Bem-Estar Social e Cidadania"], ["#Agronomia", 512, 74, 3, "Agroindústria"],
  ["#Sustentabilidade", 438, 78, 4, "Meio Ambiente e Sustentabilidade"], ["#InteligenciaArtificial", 402, 66, 9, "Energia e Conectividade"],
  ["#TVConfea", 318, 71, 5, "Bem-Estar Social e Cidadania"], ["#Saneamento", 214, 58, 12, "Saneamento Básico"],
  ["#Mobilidade", 196, 55, 15, "Mobilidade"], ["#RecursosHidricos", 142, 62, 8, "Água"],
].map(([name, mentions, pos, neg, axis]) => ({
  name: name as string, group: "Hashtag", mentions: mentions as number, pos: pos as number, neg: neg as number, axis: axis as string,
}));

const peopleSeeds: Seed[] = [
  ["Presidente do Confea", "Autoridades", 742, 68, 8], ["Governador de Sergipe", "Autoridades", 516, 61, 14],
  ["Palestrante — Painel de IA", "Palestrantes", 468, 79, 4], ["Palestrante — Transição energética", "Palestrantes", 322, 74, 5],
  ["Presidente do Crea-SE", "Presidentes do CREA", 388, 72, 6], ["Presidente do Crea-BA", "Presidentes do CREA", 164, 69, 5],
  ["Conselheiro federal — Agronomia", "Conselheiros", 142, 64, 7], ["Influenciador — Engenharia civil", "Influenciadores", 296, 76, 6],
  ["Influenciadora — Agro", "Influenciadores", 218, 73, 5], ["Participantes (estudantes)", "Participantes", 604, 63, 13],
].map(([name, group, mentions, pos, neg]) => ({
  name: name as string, group: group as string, mentions: mentions as number, pos: pos as number, neg: neg as number,
  axis: "Bem-Estar Social e Cidadania",
}));

const programSeeds: Seed[] = [
  ["Cerimônia de abertura da 81ª SOEA", "Solenidades/Premiações", "Arena Principal", "Dia 1", "19h00", "Presidente do Confea", 924, 78, 4, "Bem-Estar Social e Cidadania"],
  ["IA aplicada à engenharia", "Palestras", "Auditório Mangabá", "Dia 2", "10h00", "Palestrante — Painel de IA", 612, 80, 4, "Energia e Conectividade"],
  ["Fórum de saneamento e recursos hídricos", "Debates/Fóruns", "Auditório Aracaju", "Dia 2", "14h30", "Presidente do Crea-SE", 348, 62, 11, "Saneamento Básico"],
  ["Transição energética no Nordeste", "Palestras", "Palco Inovação", "Dia 3", "09h30", "Palestrante — Transição energética", 402, 74, 5, "Energia e Conectividade"],
  ["Workshop de agricultura de precisão", "Workshops", "Sala 3", "Dia 3", "15h00", "Influenciadora — Agro", 214, 77, 3, "Agroindústria"],
  ["Minicurso BIM para obras públicas", "Minicursos", "Sala 5", "Dia 4", "08h30", "Influenciador — Engenharia civil", 176, 71, 6, "Mobilidade"],
  ["CONTECC — Apresentação de trabalhos", "CONTECC", "Arena Conhecimento", "Dia 4", "13h00", "Participantes (estudantes)", 288, 73, 5, "Meio Ambiente e Sustentabilidade"],
  ["Show de encerramento", "Atrações", "Palco Principal", "Dia 5", "21h00", "", 356, 82, 3, "Bem-Estar Social e Cidadania"],
].map(([name, format, space, date, hour, person, mentions, pos, neg, axis]) => ({
  name: name as string, group: format as string, mentions: mentions as number, pos: pos as number, neg: neg as number,
  axis: axis as string, space: space as string, date: date as string, hour: hour as string, person: (person as string) || undefined,
}));

const tvSeeds: Seed[] = [
  ["Transmissão ao vivo — Abertura", "Transmissão", 412, 77, 4], ["Entrevistas nos corredores", "Entrevistas", 236, 74, 5],
  ["Boletim diário TV CONFEA", "Boletim", 198, 70, 4], ["Cortes das palestras", "Cortes", 174, 76, 3],
  ["Bastidores da SOEA", "Bastidores", 132, 81, 2],
].map(([name, group, mentions, pos, neg]) => ({
  name: name as string, group: group as string, mentions: mentions as number, pos: pos as number, neg: neg as number,
  axis: "Energia e Conectividade",
}));

function dataset(key: AreaKey, seeds: Seed[], salt: number, templates: string[], groupLabel: string, itemLabel: string): AreaDataset {
  const items = build(seeds, salt);
  return { key, items, posts: postsFor(items, templates, salt), groupLabel, itemLabel };
}

export const areaData: Record<AreaKey, AreaDataset> = {
  infra: dataset("infra", infraSeeds, 1, [
    "Fila grande no {x} logo cedo na 81ª SOEA, mas a equipe está organizando bem.",
    "Comentário sobre {x}: poderia melhorar para os próximos dias do evento em Aracaju.",
    "Gostei muito de {x} aqui na SOEA, tudo bem sinalizado e funcionando.",
  ], "Categoria", "Categoria"),
  hashtags: dataset("hashtags", hashtagSeeds, 2, [
    "Primeiro dia incrível na Semana Oficial da Engenharia e da Agronomia! {x}",
    "Debates de alto nível sobre o futuro do Nordeste. {x}",
    "Registro da cobertura de hoje em Sergipe {x}",
  ], "Grupo", "Hashtag"),
  people: dataset("people", peopleSeeds, 3, [
    "Fala marcante de {x} sobre o papel da engenharia no desenvolvimento do país.",
    "{x} destacou a importância da valorização profissional na 81ª SOEA.",
    "Repercussão da participação de {x} no evento em Aracaju.",
  ], "Categoria", "Pessoa"),
  program: dataset("program", programSeeds, 4, [
    "Sala cheia em \"{x}\". Conteúdo excelente!",
    "Acompanhei \"{x}\" e saí com muitas ideias para aplicar.",
    "Resumo de \"{x}\" na 81ª SOEA — vale conferir a gravação.",
  ], "Formato", "Atividade"),
  tv: dataset("tv", tvSeeds, 5, [
    "Assistindo {x} pela TV CONFEA, cobertura muito completa.",
    "{x}: ótima iniciativa da TV CONFEA para quem não pôde ir a Sergipe.",
    "Compartilhando o link de {x} com a turma da faculdade.",
  ], "Formato", "Conteúdo"),
};

export const areaMeta: Record<AreaKey, { title: string; description: string }> = {
  infra: { title: "Infraestrutura", description: "Ocorrências sobre a estrutura do evento e a experiência dos participantes." },
  hashtags: { title: "Hashtags", description: "Hashtags presentes no monitoramento, volume, alcance e conteúdos associados." },
  people: { title: "Pessoas & Repercussão", description: "Repercussão de autoridades, palestrantes, conselheiros, presidentes de CREA, influenciadores e participantes." },
  program: { title: "Programação", description: "Repercussão das atividades da programação oficial: formato, espaço, data e horário." },
  tv: { title: "TV CONFEA", description: "Conteúdos e repercussão da TV CONFEA (separada do Sistema Confea/Crea/Mútua)." },
};
