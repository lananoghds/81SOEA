import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/lib/supabase";
const soeaAvatarUrl = "/soea-profile.png";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar · Monitoramento da 81ª SOEA" },
      { name: "description", content: "Acesso restrito ao painel de monitoramento da 81ª SOEA." },
      { property: "og:title", content: "Entrar · Monitoramento da 81ª SOEA" },
      { property: "og:description", content: "Acesso restrito ao painel de monitoramento da 81ª SOEA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function translate(message: string) {
  if (/invalid login/i.test(message)) return "E-mail ou senha incorretos.";
  if (/email not confirmed/i.test(message)) return "Confirme seu e-mail antes de entrar.";
  if (/already registered/i.test(message)) return "Este e-mail já está cadastrado.";
  if (/password/i.test(message)) return "A senha deve ter pelo menos 6 caracteres.";
  return "Não foi possível concluir. Tente novamente.";
}

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    if (!email.includes("@")) return setError("Informe um e-mail válido.");
    if (password.length < 6) return setError("A senha deve ter pelo menos 6 caracteres.");
    setLoading(true);
    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) return setError(translate(error.message));
      navigate({ to: "/" });
    } else {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin },
      });
      setLoading(false);
      if (error) return setError(translate(error.message));
      if (data.session) navigate({ to: "/" });
      else setInfo("Conta criada. Verifique seu e-mail para confirmar o acesso.");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-lg border bg-card p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <img src={soeaAvatarUrl} alt="81ª SOEA" className="h-14 w-16 rounded-md object-cover" />
          <div>
            <h1 className="text-lg font-extrabold">Monitoramento da 81ª SOEA</h1>
            <p className="text-xs text-muted-foreground">Social Listening e Performance Digital</p>
          </div>
        </div>
        <h2 className="mt-6 text-sm font-bold">{mode === "login" ? "Entrar" : "Criar acesso"}</h2>
        <label className="mt-3 block text-xs font-semibold text-muted-foreground">
          E-mail
          <Input type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1" />
        </label>
        <label className="mt-3 block text-xs font-semibold text-muted-foreground">
          Senha
          <div className="relative mt-1">
            <Input
              type={show ? "text" : "password"}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pr-10"
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute inset-y-0 right-0 grid w-10 place-items-center text-muted-foreground"
              aria-label={show ? "Ocultar senha" : "Mostrar senha"}
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </label>
        {error && <p className="mt-3 rounded-md bg-destructive/10 p-2 text-xs text-destructive">{error}</p>}
        {info && <p className="mt-3 rounded-md bg-accent p-2 text-xs text-primary">{info}</p>}
        <Button type="submit" className="mt-4 w-full" disabled={loading}>
          {loading && <Loader2 className="animate-spin" />}
          {mode === "login" ? "Entrar" : "Criar acesso"}
        </Button>
        <button
          type="button"
          onClick={() => setMode((m) => (m === "login" ? "signup" : "login"))}
          className="mt-4 w-full text-center text-xs text-muted-foreground hover:text-primary"
        >
          {mode === "login" ? "Ainda não tem acesso? Criar conta" : "Já tem acesso? Entrar"}
        </button>
      </form>
    </div>
  );
}
