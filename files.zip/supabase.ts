import { createClient } from "@supabase/supabase-js";

// Projeto Supabase de produção da dashboard. A chave publishable/anon é pública.
// Fluxo: Dashboard → Supabase → public.mentions. A ingestão (V-Tracker → Edge Function
// Smart Task → public.mentions) roda no Supabase; a VTRACKER_API_KEY nunca vem ao frontend.
// URL e chave vêm de variáveis de ambiente (.env local / painel da hospedagem).
const SUPABASE_URL = import.meta.env["VITE_EXTERNAL_SUPABASE_URL"] as string | undefined;
const SUPABASE_ANON_KEY = import.meta.env["VITE_EXTERNAL_SUPABASE_ANON_KEY"] as string | undefined;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error(
    "Variáveis do Supabase ausentes: defina VITE_EXTERNAL_SUPABASE_URL e " +
      "VITE_EXTERNAL_SUPABASE_ANON_KEY (veja .env.example).",
  );
}

const isBrowser = typeof window !== "undefined";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: isBrowser ? window.localStorage : undefined,
    persistSession: isBrowser,
    autoRefreshToken: isBrowser,
  },
});
