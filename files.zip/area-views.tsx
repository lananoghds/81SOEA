import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AlertTriangle, ExternalLink, Flame, TrendingUp } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { InfoTip, Reading, SectionTitle, number, panel, sentimentClasses } from "./overview-dashboard";
import { areaData, areaMeta, periodLabels, thematicAxes } from "@/mocks/soea-areas";
import type { AreaItem, AreaKey } from "@/types/areas";

const compact = new Intl.NumberFormat("pt-BR", { notation: "compact", maximumFractionDigits: 1 });
const ALL = "Todos";
const chartColors = ["var(--primary)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)"];

function FilterSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <label className="min-w-0 text-[11px] font-semibold text-muted-foreground">
      {label}
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="mt-1 h-9 w-full min-w-36">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {[ALL, ...options].map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}

function Kpi({ label, value, info }: { label: string; value: string; info: string }) {
  return (
    <article className={`${panel} p-4`}>
      <div className="flex items-center justify-between gap-2">
        <p className="truncate text-xs font-semibold text-muted-foreground">{label}</p>
        <InfoTip label={label} text={info} />
      </div>
      <strong className="mt-1 block text-2xl font-extrabold tabular-nums">{value}</strong>
    </article>
  );
}

function predominant(item: AreaItem) {
  const s = item.sentiment;
  if (s.positivo >= s.neutro && s.positivo >= s.negativo) return "Positivo" as const;
  if (s.neutro >= s.negativo) return "Neutro" as const;
  return "Negativo" as const;
}

export function AreaModule({ area }: { area: AreaKey }) {
  const data = areaData[area];
  const meta = areaMeta[area];
  const [platform, setPlatform] = useState(ALL);
  const [sentiment, setSentiment] = useState(ALL);
  const [group, setGroup] = useState(ALL);
  const [axis, setAxis] = useState(ALL);
  const [selected, setSelected] = useState<string | null>(null);
  const [compare, setCompare] = useState<string[]>([]);

  const groups = useMemo(() => [...new Set(data.items.map((i) => i.group))], [data]);
  const axes = useMemo(
    () => thematicAxes.filter((a) => data.items.some((i) => i.axis === a)),
    [data],
  );
  const platformOptions = Object.keys(data.items[0]?.platforms ?? {});

  const items = useMemo(
    () =>
      data.items
        .filter((i) => group === ALL || i.group === group)
        .filter((i) => axis === ALL || i.axis === axis)
        .filter((i) => sentiment === ALL || predominant(i) === sentiment)
        .map((i) => {
          if (platform === ALL) return i;
          const m = i.platforms[platform] ?? 0;
          const f = i.mentions ? m / i.mentions : 0;
          return {
            ...i,
            mentions: m,
            reach: Math.round(i.reach * f),
            engagement: Math.round(i.engagement * f),
            trend: i.trend.map((t) => Math.round(t * f)),
          };
        }),
    [data, group, axis, sentiment, platform],
  );

  const posts = data.posts.filter(
    (p) =>
      items.some((i) => i.name === p.item) &&
      (platform === ALL || p.platform === platform) &&
      (sentiment === ALL || p.sentiment === sentiment) &&
      (!selected || p.item === selected),
  );

  const total = items.reduce((a, i) => a + i.mentions, 0);
  const reach = items.reduce((a, i) => a + i.reach, 0);
  const engagement = items.reduce((a, i) => a + i.engagement, 0);
  const pos = total ? Math.round(items.reduce((a, i) => a + i.sentiment.positivo * i.mentions, 0) / total) : 0;
  const neg = total ? Math.round(items.reduce((a, i) => a + i.sentiment.negativo * i.mentions, 0) / total) : 0;
  const byVolume = [...items].sort((a, b) => b.mentions - a.mentions);
  const byRepercussion = [...items].sort((a, b) => b.engagement - a.engagement);
  const compared = compare.length ? items.filter((i) => compare.includes(i.name)) : byVolume.slice(0, 3);
  const evolution = periodLabels.map((label, idx) => ({
    label,
    ...Object.fromEntries(compared.map((i) => [i.name, i.trend[idx] ?? 0])),
  }));
  const sentimentRows = byVolume.slice(0, 8).map((i) => ({
    name: i.name,
    Positivo: i.sentiment.positivo,
    Neutro: i.sentiment.neutro,
    Negativo: i.sentiment.negativo,
  }));
  const publishers = Object.entries(
    posts.reduce<Record<string, { handle: string; count: number; eng: number }>>((acc, p) => {
      const cur = acc[p.author] ?? { handle: p.handle, count: 0, eng: 0 };
      acc[p.author] = { handle: p.handle, count: cur.count + 1, eng: cur.eng + p.engagement };
      return acc;
    }, {}),
  )
    .sort((a, b) => b[1].eng - a[1].eng)
    .slice(0, 5);

  const toggleCompare = (name: string) =>
    setCompare((c) => (c.includes(name) ? c.filter((n) => n !== name) : [...c, name].slice(-4)));

  const empty = items.length === 0;

  return (
    <div className="mx-auto max-w-[1600px] space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold sm:text-3xl">{meta.title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{meta.description}</p>
          <p className="mt-1 text-[11px] font-semibold text-primary">Dados de demonstração · Fonte prevista: V-Tracker</p>
        </div>
      </div>

      <section className={`${panel} grid grid-cols-2 gap-3 p-4 md:grid-cols-4`}>
        <FilterSelect label="Plataforma" value={platform} options={platformOptions} onChange={setPlatform} />
        <FilterSelect label="Sentimento" value={sentiment} options={["Positivo", "Neutro", "Negativo"]} onChange={setSentiment} />
        <FilterSelect label={data.groupLabel} value={group} options={groups} onChange={setGroup} />
        <FilterSelect label="Eixo temático" value={axis} options={axes} onChange={setAxis} />
      </section>

      {empty ? (
        <article className={`${panel} p-8 text-center text-sm text-muted-foreground`}>
          Não há dados suficientes para os filtros selecionados.
        </article>
      ) : (
        <>
          <section className="grid grid-cols-2 gap-3 lg:grid-cols-5">
            <Kpi label="Ocorrências" value={number.format(total)} info="Quantidade de ocorrências identificadas no período e filtros selecionados." />
            <Kpi label="Alcance estimado" value={compact.format(reach)} info="Alcance estimado conforme disponibilizado pelo V-Tracker." />
            <Kpi label="Engajamento" value={compact.format(engagement)} info="Engajamento informado pela fonte para as ocorrências relacionadas." />
            <Kpi label="Sentimento positivo" value={`${pos}%`} info="Parcela de ocorrências classificadas como positivas pela fonte." />
            <Kpi label="Sentimento negativo" value={`${neg}%`} info="Parcela de ocorrências classificadas como negativas pela fonte." />
          </section>

          <section className="grid gap-5 xl:grid-cols-2">
            <article className={panel}>
              <SectionTitle title={`${data.itemLabel}s com maior volume`} subtitle="Clique para ver as ocorrências relacionadas" info="Ranking por quantidade de ocorrências." />
              <div className="space-y-1 px-5 pb-4">
                {byVolume.slice(0, 10).map((i) => (
                  <button
                    key={i.name}
                    type="button"
                    onClick={() => setSelected(selected === i.name ? null : i.name)}
                    className={`w-full rounded-md px-2 py-2 text-left transition hover:bg-muted ${selected === i.name ? "bg-accent ring-1 ring-primary" : ""}`}
                  >
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className="truncate font-semibold">{i.name}</span>
                      <span className="tabular-nums text-muted-foreground">{number.format(i.mentions)}</span>
                    </div>
                    <div className="mt-1 h-1.5 rounded-full bg-muted">
                      <div className="h-full rounded-full bg-primary" style={{ width: `${(i.mentions / (byVolume[0]?.mentions || 1)) * 100}%` }} />
                    </div>
                  </button>
                ))}
              </div>
              <Reading>
                {byVolume[0]?.name} concentra o maior volume de ocorrências ({number.format(byVolume[0]?.mentions ?? 0)}).
              </Reading>
            </article>

            <article className={panel}>
              <SectionTitle title="Maior repercussão" subtitle="Ordenado por engajamento" info="Itens com maior engajamento somado nas ocorrências." />
              <div className="overflow-x-auto px-5 pb-4">
                <table className="w-full min-w-[520px] text-sm">
                  <thead className="text-left text-[11px] text-muted-foreground">
                    <tr>
                      <th className="py-2">{data.itemLabel}</th>
                      <th>Engajamento</th>
                      <th>Alcance</th>
                      <th>Sentimento</th>
                      <th>Comparar</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {byRepercussion.slice(0, 8).map((i) => (
                      <tr key={i.name}>
                        <td className="max-w-56 truncate py-2 font-semibold">{i.name}</td>
                        <td className="tabular-nums">{compact.format(i.engagement)}</td>
                        <td className="tabular-nums">{compact.format(i.reach)}</td>
                        <td>
                          <span className={`rounded px-2 py-0.5 text-[10px] font-semibold ${sentimentClasses[predominant(i)]}`}>{predominant(i)}</span>
                        </td>
                        <td>
                          <input type="checkbox" checked={compare.includes(i.name)} onChange={() => toggleCompare(i.name)} aria-label={`Comparar ${i.name}`} className="accent-[var(--primary)]" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Reading>{byRepercussion[0]?.name} lidera em repercussão no período.</Reading>
            </article>
          </section>

          <section className="grid gap-5 xl:grid-cols-2">
            <article className={panel}>
              <SectionTitle title="Evolução das ocorrências" subtitle={compare.length ? "Comparação selecionada" : "Top 3 por volume · marque itens na tabela para comparar"} info="Ocorrências por dia do evento." />
              <div className="h-72 px-3 pb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={evolution}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} />
                    <YAxis tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} />
                    <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    {compared.map((i, idx) => (
                      <Line key={i.name} dataKey={i.name} stroke={chartColors[idx % 4]} strokeWidth={2} dot={false} />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </article>
            <article className={panel}>
              <SectionTitle title="Sentimento por item" subtitle="Classificação da fonte (%)" info="Distribuição de sentimento conforme classificação do V-Tracker." />
              <div className="h-72 px-3 pb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={sentimentRows} layout="vertical" margin={{ left: 10 }}>
                    <XAxis type="number" domain={[0, 100]} hide />
                    <YAxis type="category" dataKey="name" width={130} tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} />
                    <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--foreground)" }} />
                    <Bar dataKey="Positivo" stackId="s" fill="var(--chart-2)" />
                    <Bar dataKey="Neutro" stackId="s" fill="var(--muted-foreground)" />
                    <Bar dataKey="Negativo" stackId="s" fill="var(--destructive)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </article>
          </section>

          {area === "program" && (
            <article className={panel}>
              <SectionTitle title="Atividades da programação" info="Atividade, formato, pessoa, espaço, data e horário são dimensões separadas." />
              <div className="overflow-x-auto px-5 pb-5">
                <table className="w-full min-w-[720px] text-sm">
                  <thead className="text-left text-[11px] text-muted-foreground">
                    <tr><th className="py-2">Atividade</th><th>Formato</th><th>Pessoa</th><th>Espaço</th><th>Data</th><th>Horário</th><th>Ocorrências</th></tr>
                  </thead>
                  <tbody className="divide-y">
                    {byVolume.map((i) => (
                      <tr key={i.name}>
                        <td className="py-2 font-semibold">{i.name}</td>
                        <td>{i.group}</td>
                        <td>{i.person ?? "—"}</td>
                        <td>{i.space}</td>
                        <td>{i.date}</td>
                        <td>{i.hour}</td>
                        <td className="tabular-nums">{number.format(i.mentions)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </article>
          )}

          <section className="grid gap-5 xl:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
            <article className={panel}>
              <SectionTitle
                title={selected ? `Ocorrências: ${selected}` : "Principais conteúdos"}
                subtitle={selected ? "Clique no item novamente para limpar" : "Ocorrências relacionadas aos filtros"}
                info="Publicações identificadas pelo monitoramento. O link é exibido somente quando a fonte fornece a URL."
              />
              <div className="divide-y">
                {posts.length === 0 && <p className="p-5 text-sm text-muted-foreground">Não há dados suficientes.</p>}
                {[...posts].sort((a, b) => b.engagement - a.engagement).slice(0, 8).map((p) => (
                  <div key={p.id} className="p-5">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <strong className="text-sm">{p.author}</strong>
                      <span className="text-muted-foreground">{p.handle}</span>
                      <span className="rounded bg-muted px-2 py-0.5">{p.platform}</span>
                      {p.profile && <span className="rounded bg-accent px-2 py-0.5 text-primary">{p.profile}</span>}
                      <span className={`rounded px-2 py-0.5 font-semibold ${sentimentClasses[p.sentiment]}`}>{p.sentiment}</span>
                      <span className="ml-auto text-muted-foreground">{p.time}</span>
                    </div>
                    <p className="mt-2 text-sm">{p.text}</p>
                    <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                      <span>{number.format(p.engagement)} de engajamento · {p.item}</span>
                      {p.url ? (
                        <a href={p.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-primary hover:underline">
                          Ver publicação <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <span>Link indisponível na fonte</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </article>
            <article className={panel}>
              <SectionTitle title="Principais publicadores" info="Publicadores nativos do V-Tracker com maior engajamento nas ocorrências filtradas." />
              <div className="space-y-3 px-5 pb-5">
                {publishers.map(([name, p]) => (
                  <div key={name} className="flex items-center justify-between gap-2 text-sm">
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{name}</p>
                      <p className="text-[11px] text-muted-foreground">{p.handle} · {p.count} ocorrência(s)</p>
                    </div>
                    <span className="tabular-nums text-muted-foreground">{number.format(p.eng)}</span>
                  </div>
                ))}
                {publishers.length === 0 && <p className="text-sm text-muted-foreground">Não há dados suficientes.</p>}
              </div>
            </article>
          </section>
        </>
      )}
    </div>
  );
}

/* Alertas derivados das novas áreas — só gera quando há dados suficientes */
export function deriveAreaAlerts() {
  const out: Array<{ id: string; type: string; what: string; when: string; topic: string; volume: number; reach: number; sentiment: string; platform: string; content: string; severity: "Alta" | "Média" | "Baixa" }> = [];
  (Object.keys(areaData) as AreaKey[]).forEach((key) => {
    areaData[key].items.forEach((i) => {
      const last = i.trend[i.trend.length - 1] ?? 0;
      const prev = i.trend[i.trend.length - 2] ?? 0;
      if (prev < 20) return; // dados insuficientes
      const growth = Math.round(((last - prev) / prev) * 100);
      const topPlatform = Object.entries(i.platforms).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "-";
      const content = areaData[key].posts.find((p) => p.item === i.name)?.text ?? "-";
      if (key === "infra" && i.sentiment.negativo >= 30)
        out.push({ id: `${key}-${i.name}-neg`, type: "Infraestrutura com sentimento negativo", what: `${i.name} com ${i.sentiment.negativo}% de ocorrências negativas`, when: periodLabels[periodLabels.length - 1]!, topic: i.name, volume: i.mentions, reach: i.reach, sentiment: `${i.sentiment.negativo}% negativo`, platform: topPlatform, content, severity: "Alta" });
      else if (growth >= 15)
        out.push({ id: `${key}-${i.name}-up`, type: key === "hashtags" ? "Crescimento de hashtag" : `Crescimento em ${areaMeta[key].title}`, what: `${i.name} cresceu ${growth}% no último dia`, when: periodLabels[periodLabels.length - 1]!, topic: i.name, volume: last, reach: i.reach, sentiment: predominant(i), platform: topPlatform, content, severity: growth >= 30 ? "Alta" : "Média" });
    });
  });
  return out.slice(0, 12);
}

export function AreaAlertsPanel() {
  const alerts = deriveAreaAlerts();
  return (
    <article className={`${panel} mx-auto mt-5 max-w-[1600px]`}>
      <SectionTitle title="Alertas das áreas temáticas" subtitle="Infraestrutura, hashtags, pessoas, programação e TV CONFEA" info="Gerados por regras determinísticas: crescimento ≥ 15% entre os dois últimos dias ou ≥ 30% de sentimento negativo em infraestrutura. Não são gerados alertas sem volume mínimo." />
      <div className="divide-y">
        {alerts.length === 0 && <p className="p-5 text-sm text-muted-foreground">Não há dados suficientes para gerar alertas.</p>}
        {alerts.map((a) => (
          <div key={a.id} className="grid grid-cols-[auto_minmax(0,1fr)] gap-3 p-5">
            <div className={`grid h-10 w-10 place-items-center rounded-md ${a.severity === "Alta" ? "bg-destructive/10 text-destructive" : "bg-accent text-primary"}`}>
              {a.severity === "Alta" ? <Flame className="h-5 w-5" /> : a.type.includes("negativo") ? <AlertTriangle className="h-5 w-5" /> : <TrendingUp className="h-5 w-5" />}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-sm font-bold">{a.type}</p>
                <span className="text-[10px] text-muted-foreground">{a.when}</span>
              </div>
              <p className="mt-1 text-sm">{a.what}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Assunto: {a.topic} · Volume: {number.format(a.volume)} · Alcance: {compact.format(a.reach)} · Sentimento: {a.sentiment} · Plataforma: {a.platform}
              </p>
              <p className="mt-1 truncate text-xs italic text-muted-foreground">“{a.content}”</p>
            </div>
          </div>
        ))}
      </div>
    </article>
  );
}
