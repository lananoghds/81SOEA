import { supabase } from "@/lib/supabase";

// Leitura da tabela existente public.mentions (estrutura preservada).
export interface MentionRow {
  id?: string | number;
  published_at?: string | null;
  plataforma?: string | null;
  sentimento?: string | null;
  engagement?: number | null;
  url?: string | null;
  raw_payload?: unknown;
  [key: string]: unknown;
}

export async function fetchMentions(opts: { from?: string; to?: string; limit?: number } = {}) {
  let q = supabase.from("mentions").select("*").order("published_at", { ascending: false });
  if (opts.from) q = q.gte("published_at", opts.from);
  if (opts.to) q = q.lte("published_at", opts.to);
  const { data, error } = await q.limit(opts.limit ?? 1000);
  if (error) throw error;
  return (data ?? []) as MentionRow[];
}
